package com.company;

/**
 * Created by swethakolalapudi on 10/10/15.
 */
public interface IShape {

    public double getArea();
    public double getPerimeter();
}
